package com.example.bdtask_flutter_29_08_2023

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
